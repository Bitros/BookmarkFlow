# BookmarkFlow
A Chromium extension which can synchronize bookmarks between Google Chrome and Microsoft Edge.
